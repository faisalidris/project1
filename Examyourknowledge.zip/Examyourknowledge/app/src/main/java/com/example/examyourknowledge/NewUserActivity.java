package com.example.examyourknowledge;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class NewUserActivity extends AppCompatActivity {
    EditText username, password, email, mobile, confirmPassword;
    RadioGroup Gender;
    Button Sign_up, Sign_in;
    SharedPreferences Figo;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);
        username = findViewById(R.id.editTextTextPersonName);
        password = findViewById(R.id.editTextTextPassword);
        email = findViewById(R.id.emailing);
        mobile = findViewById(R.id.editTextPhone);
        confirmPassword = findViewById(R.id.editTextTextPassword2);
        Gender = findViewById(R.id.Gender);
        Sign_up = findViewById(R.id.buttonRegister);
        Sign_in = findViewById(R.id.orSignIn);

        Figo = getSharedPreferences("UserInfo", 0);
        {
            Sign_up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String user_value = username.getText().toString();
                    String user_password = password.getText().toString();
                    String user_password5 = confirmPassword.getText().toString();
                    String mail_value = email.getText().toString();
                    String mobile_No = mobile.getText().toString();
                    RadioButton checkedBtn = findViewById(Gender.getCheckedRadioButtonId());
                    String gender_value = checkedBtn.getText().toString();
                    Log.d("geander", gender_value);
                    if (!check3(user_value, user_password, mail_value, mobile_No, gender_value) && (user_password.equals(user_password5))) {
                        SharedPreferences.Editor editor = Figo.edit();
                        editor.putString("username", user_value);
                        editor.putString("password", user_password);
                        editor.putString("email", mail_value);
                        editor.putString("mobile", mobile_No);
                        editor.putString("gender", gender_value);
                        editor.apply();
                        Toast.makeText(NewUserActivity.this, "User Register Successfully !", Toast.LENGTH_SHORT).show();
                        {
                            Intent  Sign_up = new Intent(NewUserActivity.this, Login.class);
                            startActivity(Sign_up);


                        }
                    } else
                        Toast.makeText(NewUserActivity.this, "Enter the values in the fields !", Toast.LENGTH_SHORT).show();
                }
            });
        }



    }

    private boolean check3(String username, String password, String email, String mobile, String gender) {
        boolean isEmpty = false;
        //// email mobile gender
        if (username.isEmpty()) {
            return true;
        } else return password.isEmpty();
    }


    public void moving(View view) {
        Intent   Sign_in = new Intent(NewUserActivity.this, Login.class);
        startActivity(  Sign_in);
    }
}

