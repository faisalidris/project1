package com.example.examyourknowledge;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    EditText username, password;
    Button confirm, registration;
    SharedPreferences Figo;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.editTextTextPersonName3);
        password = findViewById(R.id.editTextTextPersonName4);
        confirm = findViewById(R.id.confirm_button);
        registration = findViewById(R.id.register_now_button);
        Figo = getSharedPreferences("UserInfo", 0);

        confirm.setOnClickListener(v -> {
            String user_value = username.getText().toString();
            String user_password = password.getText().toString();
            String registeredUsername = Figo.getString("username", "");
            String registeredPassword = Figo.getString("password", "");
            if (user_value.equals(registeredUsername) & user_password.equals(registeredPassword)
            ) {
                Intent confirm = new Intent(Login.this,
                        ActivePage.class);
                startActivity(confirm);
            } else
                Toast.makeText(Login.this, "Enter the values in the fields !", Toast.LENGTH_SHORT).show();

        });


    }

    ;

    public void registration(View view) {
        Intent registration = new Intent(Login.this, NewUserActivity.class);
        startActivity(registration);

    }


    public void confirm(View view) {
        Intent confirm = new Intent(Login.this,
                ActivePage.class);
        startActivity(confirm);
    }
};